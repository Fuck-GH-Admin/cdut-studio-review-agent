# CDUT-R02-QA-T06-A

- 研究日期：2026-10-24（北京时间）
- 权威原件快照：`feat/v3-r02-template-library` @ `150acfe761cb7ad0424a2ca009fd57f12dbfddfd`
- 实现分支：`feat/v3-r02/templates-T06-A`
- 当前 PR 头：`da922e2bf257e8ef31a80c93b1438cf5ce9f3b75`
- Pull Request： https://github.com/Fuck-GH-Admin/cdut-studio-review-agent/pull/221

## 包内文件
1. `AUDIT-T06-A.md` — 五份模板的独立结论、政策证据、P0–P3 统计、问题和跨模板边界。
2. `ISSUES-T06-A.tsv` — 固定 11 列的问题台账，共 10 条 P2 问题。
3. `STATUS-T06-A.tsv` — 每个模板一行的质量和政策证据状态。
4. `patches/T06-T02.md` — 完整 Markdown 修订稿，与实现分支中的审阅副本相同。
5. `README.md` — 本说明。

## 原件完整性
五份原件的 UTF-8 字节数和 SHA-256 均按原始字节追加一个 LF 后重新计算，并与 `00_模板清单_128.tsv` 完全一致。模块 metadata 的 `sourceDocumentSha256` 指向未修改的 `research-original/` 原件。

| 原件 | 清单 bytes | SHA-256 |
|---|---:|---|
| T06-T01.md | 131422 | 2efc9075200a0e3e1cfc7913cb54ef45188915ae80a2660d94444f3a058e6283 |
| T06-T02.md | 144141 | 94a99293a788f282749f4c1d65f9261b77dea87888beea69833e19267bc8a9b8 |
| T06-T03.md | 137459 | 8bcc340beef42dfb629c71c20d129e135866b5d2d99a6fe284c2186bbf4040b7 |
| T06-T04.md | 150652 | 4d5ef8d8a0e461e9fd6a4cec7ca4cb0408a2b3514761d9ccf9581ef543072d0e |
| T06-T05.md | 138261 | 1534296d34557bced38965f377fd34cceb3bb0e385fd47f24756c3e2f1aae87d |

## 修订与限制
- 模板 ID、正式名称和边界未修改；原件只读。
- 唯一安全正文修订为 T06-T02 SRC-006：从已废止的成理校研〔2023〕6号更新到成理校研〔2024〕41号。
- 五份定义均为 `draft`、`policyVersionIds=[]`、`autoPassPolicy.enabled=false`、`officialSchoolTemplate:false`。未确认规则保留人工复核门禁。本包不是校方正式模板或审批结果。
- 当前未完全确认：2026/2027 年招生资格细则、最新博士导师增列规则、个人指标算法与签发权限、研究生课程现行规则、导师工作量公式、年度任务和复核授权。

## 测试结果
PR CI #2519（代码提交 `e8341a3e74468f0484bb3ad8844f0ffb30952b0e`）成功：TypeScript typecheck、package boundaries、built-in skin contract、main/preload/renderer build、unit/regression suite 全部通过。Review Baseline CI #1667 和 D2 Scoped Pi Review Tests #1618 也成功。后续 `da922e2b` 只更新审计报告，不修改运行时代码或测试代码。
