# CDUT-R02-QA-T01-B.zip

## 交付清单
- `AUDIT-T01-B.md`：四份模板独立结论、政策证据、P0–P3 统计、跨模板边界和实际 CI 结果。
- `ISSUES-T01-B.tsv`：机器可读问题台账，固定列名。
- `STATUS-T01-B.tsv`：每份模板的质量/政策状态与问题数量。
- `patches/T01-T07.md`：完整 Markdown 修订稿；仅将 fenced YAML 元数据规范化为顶部 YAML frontmatter。
- `patches/T01-T09.md`：完整 Markdown 修订稿；仅将裸 metadata 键值规范化为顶部 YAML frontmatter，并补充正式 H1 和 `official_school_template:false`。

## 研究日期与来源范围
- 研究日期：2026-10-24（Asia/Shanghai）。
- 仓库：`Fuck-GH-Admin/cdut-studio-review-agent`。
- 权威集成分支：`feat/v3-r02-template-library`，读取基线 HEAD `150acfe761cb7ad0424a2ca009fd57f12dbfddfd`。
- 已完整读取四份 `research-original/` 原件以及 R02 统一审查标准、V3 实现与提交契约、文件所有权、128 项清单、16 项缺口清单和总集成契约。
- 已核对成都理工大学 2022 本科课程教学基本规范、2024/2025 学期考试通知、2023 实验室技术安全管理办法及教育部实习/实验室安全指导。报告给出文号、条款、日期与官方 URL。

## 修订稿与原件的关系
- `research-original/` 中的四份原件保持只读。
- ZIP 内 `patches/` 的两份文件是完整修订 Markdown，不是 diff。
- T01-T07 仅调整 YAML metadata 的位置和边界；T01-T09 仅规范化 metadata、增加正式 H1 并显式声明非校方正式模板。未改业务规则、正式 ID、正式名称或业务边界。
- T01-T06、T01-T08 没有发现可安全修改的正文缺陷，因此未另放 patch。
- 每份原稿的 SHA-256/字节数均已按 UTF-8 原始内容追加一个 LF 计算，并与权威清单逐项相符。Runtime metadata 中的 SHA-256 指向原始研究文件；审阅后版本路径单独记录。

## 质量与政策证据分开记录
- 四份模板的 `quality_status=PASS`，反映安全修订后无未解决的设计质量缺陷。
- 四份模板的 `policy_evidence_status=PARTIAL`，各有 1 个 P2 政策证据缺口；这不等于模板设计质量差。
- 两个 P3 metadata 格式问题均已在修订稿中修复，问题台账保留发现记录并标注 patched。
- 总计 P0=0、P1=0、P2=4、P3=2。

## 测试结果
- PR CI run [#40012021753](https://github.com/Fuck-GH-Admin/cdut-studio-review-agent/actions/runs/40012021753) 成功：typecheck、package boundaries、built-in skin surface contract、main/preload/renderer build、unit/regression tests 全部成功。
- `T01-B.test.ts` 5 项专项测试全部通过；整套测试共 5031 tests across 602 files，5026 pass、0 fail。
- Review Baseline CI run [#40012021769](https://github.com/Fuck-GH-Admin/cdut-studio-review-agent/actions/runs/40012021769) 成功。D2 Scoped Pi run 的相关 job 均为 success；该 workflow 总状态在审计时尚未结束。
- 本地命令未执行，原因是工具容器没有本地克隆且无法解析 github.com；不虚报本地通过。

## 限制与使用说明
- 已有官方来源不代表已确认 2026 最新修订、研究生适用规则、正式表单或审批授权。
- 所有模板只能用于本地研究、事实抽取、证据覆盖核对和审阅建议；不得把模型结果当成校方正式通过/拒绝。
- 未确认政策规则保持人工复核；不伪造 PolicyVersion、学校批准人、系统回写或正式批准权限。
