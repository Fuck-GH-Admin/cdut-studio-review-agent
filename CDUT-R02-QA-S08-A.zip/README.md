# CDUT-R02-QA-S08-A

- 研究日期：2026-10-24
- 仓库：Fuck-GH-Admin/cdut-studio-review-agent
- 实现分支：feat/v3-r02/templates-S08-A
- 当前批次提交：0596cada704be70042a7cfcf7fe29843732e3acd
- PR：https://github.com/Fuck-GH-Admin/cdut-studio-review-agent/pull/237
- 适用范围：S08-T01、S08-T03、S08-T04、S08-T05、S08-T06

## 交付清单

1. `AUDIT-S08-A.md`：批次摘要、五份模板独立结论、政策证据、P0–P3 数量、逐条问题、跨模板边界、官方来源与实施边界。
2. `ISSUES-S08-A.tsv`：19 条机器可读问题记录；固定 11 列。
3. `STATUS-S08-A.tsv`：每份模板一行；固定 10 列。
4. `patches/S08-T04.md`：S08-T04 完整审阅修订稿。
5. `README.md`：本说明。

## 原件、审阅版与修订稿

- 原始文件均位于 `docs/design/review-agent/business-templates/R02/research-original/`，保持只读。
- 五份审阅版已提交到 `docs/design/review-agent/business-templates/R02/{ID}.md`。
- S08-T04 是唯一正文修订：在标题后增加非校方正式模板声明。其余四份只将审阅副本规范为一个终端 LF，不改变业务语义。
- 运行时定义、专项测试、审查报告和问题 TSV 以 PR #237 中当前批次提交为准；本 ZIP 是审查材料备份，不替代代码 PR。

## 来源范围

本批读取权威集成分支当前版本中的五份研究原件、R02 总索引/派发说明、V3 实现契约、统一审查标准、文件所有权、128 项清单、16 项缺失项清单、总集成提示词及辅助说明。官方来源主要包括：

- 成理校研〔2024〕23号《研究生指导教师岗位管理办法》；
- 成理校研〔2021〕12号《研究生培养环节管理办法（试行）》；
- 成理校研〔2024〕41号《研究生学位论文评阅实施办法》；
- 成理校研〔2025〕17号工程博士论文/实践成果专项细则；
- 成理研〔2026〕1号年度毕业答辩和学位申请安排；
- 《中华人民共和国学位法》；
- 学位办〔2026〕26号专业学位研究生以实践成果申请学位意见；
- 中国科学院文献情报中心 2026 年停止发布期刊分区表的声明。

详细 URL、文号、日期和条款见 `AUDIT-S08-A.md`。

## 限制与状态

- 五份模板均为 `PASS_WITH_WARNINGS`，政策证据状态均为 `PARTIAL`；问题统计 P0=0、P1=0、P2=13、P3=6。
- S08-T02（研究生个人培养计划变更和课程安排审核）原件缺失。本批未创建空壳或以邻项替代。
- 2024学籍办法全文、2025新版授位实施细则正文/附件、部分政策的现行性/适用批次、2026期刊分区替代口径、格式检测门槛仍需校方确认。未知条件不得自动产生正式通过/拒绝。
- 本地终端可用，但当前工作目录没有该仓库的本地克隆。实际执行 `git ls-remote https://github.com/Fuck-GH-Admin/cdut-studio-review-agent.git refs/heads/feat/v3-r02-template-library`，返回 `fatal: unable to access 'https://github.com/Fuck-GH-Admin/cdut-studio-review-agent.git/': Could not resolve host: github.com`。因此未能在本地运行 `bun test`、`bun run typecheck` 或 `bun run check:boundaries`。生成本 ZIP 时 PR 检查仍在排队/运行，尚无可引用的最终通过结果。

## 实现边界

本批所有 TemplateVersion 均为非校方正式 draft，`schemaVersion: 2`、`catalogKind: 'builtin'`、`policyVersionIds: []`、`autoPassPolicy.enabled=false`，不执行学校远端写回。共享注册器、模板存储、shared 类型、Main/Case/Run/Batch/Decision/Outbox、IPC、preload 和 renderer 未被本批修改；统一注册及 criterion→V3 Plan/Run 编译接线仍由集成 Owner 完成。
