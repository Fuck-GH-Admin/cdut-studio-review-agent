# CDUT R02 QA — T08-A

- **Package:** `CDUT-R02-QA-T08-A.zip`
- **Research date:** 2026-10-24 (Asia/Shanghai)
- **Repository:** https://github.com/Fuck-GH-Admin/cdut-studio-review-agent
- **Implementation branch:** `feat/v3-r02/templates-T08-A`
- **Implementation commit at packaging:** `2653418db17e1a75ac160c5977667720dec8ff90`
- **PR:** https://github.com/Fuck-GH-Admin/cdut-studio-review-agent/pull/239
- **CI result at that commit:** **PASS** — PR CI passed workspace typecheck, package-boundary checks, built-in skin surface contract, main/preload/renderer build, and unit/regression tests. Review Baseline CI and D2 Scoped Pi Review Tests also passed.
- **Integration base at dispatch:** `feat/v3-r02-template-library`, HEAD `150acfe761cb7ad0424a2ca009fd57f12dbfddfd`
- **Scope:** T08-T01 through T08-T05; five original research Markdown files; required R02 dispatch/implementation-contract documents; the 128-template manifest; and relevant official public sources.

## Package contents

1. `AUDIT-T08-A.md` — batch findings and independent per-template conclusions.
2. `ISSUES-T08-A.tsv` — 23 machine-readable issues, with the required fixed columns.
3. `STATUS-T08-A.tsv` — one status row per template.
4. `patches/T08-T01.md` — complete reviewed Markdown copy with the SRC-008 currentity status corrected.
5. `patches/T08-T02.md` — complete reviewed Markdown copy with the SRC-011 source record and §14 source assessment corrected.

## Patch relationship

- The five `research-original/*.md` files remain unchanged.
- The only content patches are the low-ambiguity correction that the Ministry of Science and Technology's official directory marks `国科发资〔2020〕132号` as ineffective, with the 2025-08-05 invalidation decision. The source remains as historical background, not a current policy basis.
- T08-T03, T08-T04, and T08-T05 have no full Markdown patch because remaining defects require authoritative school policy or permission decisions; guessing those details would be unsafe.
- Runtime metadata records the actual byte-level hash of each reviewed Markdown file separately from the manifest's expected hash.

## Official source scope

The audit links official Chengdu University of Technology recruitment notices for their exact 2026 batches, the Ministry of Industry and Information Technology's 2026 notice, the Ministry of Science and Technology's 2020 notice and 2025 invalidation decision, the Labor Contract Law and its implementing regulation, the Personal Information Protection Law, and Chengdu University of Technology's 2023 laboratory safety rules and 2024 project/funding rules.

## Limitations

- Policy evidence remains `PARTIAL`; this package is not a school-approved template set.
- Current school-wide signatory authority, project-employment approval forms, renewal/pay/term-change authority, and exit/handover authority remain unconfirmed.
- T08-T06 (postdoctoral entry, in-service assessment, and exit qualification) is an explicit catalog gap; no placeholder template is invented.
- Runtime definitions stay draft-only, with `policyVersionIds=[]` and auto-pass disabled. No school-side write-back or inferred final approver is created.
- The local commands were not invoked from this chat session, but the PR CI at the recorded commit passed the corresponding typecheck, boundary, build, and unit/regression-test steps.
